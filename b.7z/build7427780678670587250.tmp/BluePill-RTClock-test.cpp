#line 1 "BluePill-RTClock-test.ino"
                                  

                                                                                               
                                                               

                                                                    
                                             
                                                    
                                           
                                                               
                                                                              
                                           

                                               
                                                      
                                                                                         
 
                                              
                                                                           
                                         
                                                                                  
                                                                     
                                            
  


#include <RTClock.h>

#include "Arduino.h"
uint8_t str2month(const char * d);
void ParseBuildTimestamp(tm_t & mt);
void SecondCount ();
void blink ();
void OnOffSerial ();
void setup();
void loop();
#line 29
RTClock rtclock (RTCSEL_LSE);              
int timezone = 8;                                
time_t tt, tt1;
tm_t mtt;
uint8_t dateread[11];
int globAlmCount = 0;
int lastGlobAlmCount;
int SPECAlmCount = 0;
int lastSPECAlmCount;
int alarmcount = 3;
uint8_t AlarmExchange = 0;
bool dispflag = true;

                                                                               
const char * weekdays[] = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
const char * months[] = {"Dummy", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
                                                                               
uint8_t str2month(const char * d)
{
    uint8_t i = 13;
    while ( (--i) && strcmp(months[i], d)!=0 );
    return i;
}
                                                                               
const char * delim = " :";
char s[128];               
                                                                               
void ParseBuildTimestamp(tm_t & mt)
{
                                                
    sprintf(s, "Timestamp: %s, %s\n", __DATE__, __TIME__);
                      
    char * token = strtok(s, delim);                   
                          
    while( token != NULL ) {
        uint8_t m = str2month((const char*)token);
        if ( m>0 ) {
            mt.month = m;
                                                                 
            token = strtok(NULL, delim);                  
            mt.day = atoi(token);
                                                             
            token = strtok(NULL, delim);                  
            mt.year = atoi(token) - 1970;
                                                               
            token = strtok(NULL, delim);                  
            mt.hour = atoi(token);
                                                               
            token = strtok(NULL, delim);                  
            mt.minute = atoi(token);
                                                                   
            token = strtok(NULL, delim);                  
            mt.second = atoi(token);
                                                                   
        }
        token = strtok(NULL, delim);
    }
}
                                                                               
                                                        
                                                                               
void SecondCount ()
{
  tt++;
}
                                                                               
                                                      
                                                                               
void blink ()
{
  digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
  globAlmCount++;
}
                                                                               
void OnOffSerial ()
{
  dispflag = !dispflag;
  SPECAlmCount++;
}
                                                                               
void setup()
{
  lastGlobAlmCount = ~globAlmCount;
  lastSPECAlmCount = ~SPECAlmCount;
  Serial.begin(115200);
  pinMode(LED_BUILTIN, OUTPUT);
                                 
  ParseBuildTimestamp(mtt);                                                             
  tt = rtclock.makeTime(mtt) + 25;                                                           
  rtclock.setTime(tt);
  tt1 = tt;
  rtclock.attachAlarmInterrupt(blink);             
  rtclock.attachSecondsInterrupt(SecondCount);                   
}
                                                                               
void loop()
{
  if ( Serial.available()>10 ) {
    for (uint8_t i = 0; i<11; i++) {
	    dateread[i] = Serial.read();
    }
    Serial.flush();
    tt = atol((char*)dateread);
    rtclock.setTime(rtclock.TimeZone(tt, timezone));                            
  }
  if (lastGlobAlmCount != globAlmCount || lastSPECAlmCount != SPECAlmCount ) {
    if (globAlmCount == 10) {                                                                                 
      rtclock.detachAlarmInterrupt();
      globAlmCount = 0;
      rtclock.createAlarm(OnOffSerial, (rtclock.getTime() + 20));                                                                
      alarmcount = 20;                                                                              
    }
    else {
      lastGlobAlmCount = globAlmCount;
      lastSPECAlmCount = SPECAlmCount;
      Serial.println(" Say hello to every guys ");
      if(dispflag == false)
      Serial.println(" SPECAlarm turn Display Off ");
      switch (AlarmExchange)  {
        case 0:
          rtclock.setAlarmTime(rtclock.getTime() + alarmcount);                                                                                  
          AlarmExchange = 1;
          break;
        case 1:
          rtclock.breakTime(rtclock.getTime() + alarmcount * 2, mtt);                                                                                   
          rtclock.setAlarmTime(mtt);
          AlarmExchange = 0;
          break;
      }
    }
  }
  if (tt1 != tt && dispflag == true )
  {
    tt1 = tt;
                                         
    rtclock.breakTime(rtclock.now(), mtt);
    sprintf(s, "RTC timestamp: %s %u %u, %s, %02u:%02u:%02u\n",
      months[mtt.month], mtt.day, mtt.year+1970, weekdays[mtt.weekday], mtt.hour, mtt.minute, mtt.second);
    Serial.print(s);
  }
}

