/*
 * mainApp.h
 *
 *  Created on: Sep 8, 2017
 *      Author: dkhairnar
 */

#ifndef MAINAPP_H_
#define MAINAPP_H_

void mainApp(void);


#endif /* MAINAPP_H_ */
